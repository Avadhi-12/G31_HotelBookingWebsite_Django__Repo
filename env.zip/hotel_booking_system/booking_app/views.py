from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.http import HttpResponse
from django.contrib import messages
from django.utils import timezone
from datetime import datetime, timedelta

from .forms import BookingForm
from .models import Booking
from hotel_app.models import Hotel, Room


@login_required
def create_booking(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.save()
            return redirect('my_bookings')
    else:
        form = BookingForm()
    return render(request, 'booking_app/booking_form.html', {'form': form})


@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(user=request.user)
    now = timezone.now()

    for booking in bookings:
        check_in_datetime = timezone.make_aware(datetime.combine(booking.check_in, datetime.min.time()))
        booking.can_modify = check_in_datetime - now > timedelta(hours=24)

    return render(request, 'booking_app/my_bookings.html', {'bookings': bookings})


@login_required
def book_room(request, hotel_id, room_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    room = get_object_or_404(Room, id=room_id)

    if not room.available:
        messages.error(request, "Sorry, this room is already booked.")
        return redirect('hotel_detail', hotel_id=hotel_id)

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.hotel = hotel
            booking.room = room

            # Validation
            if booking.check_in < timezone.now().date():
                messages.error(request, "Check-in cannot be in the past.")
                return redirect('book_room', hotel_id=hotel_id, room_id=room_id)
            if booking.check_out <= booking.check_in:
                messages.error(request, "Check-out must be after check-in.")
                return redirect('book_room', hotel_id=hotel_id, room_id=room_id)

            booking.save()

            room.available = False
            room.save()

            messages.success(request, "Room booked successfully!")
            return redirect('my_bookings')
    else:
        form = BookingForm()

    return render(request, 'booking_app/book_room.html', {
        'form': form,
        'hotel': hotel,
        'room': room,
    })


@staff_member_required
def admin_dashboard(request):
    hotels = Hotel.objects.all()
    bookings = Booking.objects.all()
    return render(request, 'hotel_app/admin_dashboard.html', {
        'hotels': hotels,
        'bookings': bookings
    })


@staff_member_required
def admin_all_bookings(request):
    bookings = Booking.objects.all()
    return render(request, 'booking_app/admin_all_bookings.html', {'bookings': bookings})


@login_required
def update_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    if request.method == 'POST':
        booking.check_in = request.POST.get('check_in')
        booking.check_out = request.POST.get('check_out')
        booking.save()
        messages.success(request, "Booking updated successfully.")
        return redirect('admin_all_bookings')
    return render(request, 'booking_app/update_booking.html', {'booking': booking})


@staff_member_required
def delete_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    if request.method == 'POST':
        booking.room.available = True
        booking.room.save()
        booking.delete()
        messages.success(request, "Booking deleted.")
        return redirect('admin_all_bookings')
    return render(request, 'booking_app/delete_booking.html', {'booking': booking})


@login_required
def update_booking_user(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)

    check_in_datetime = timezone.make_aware(datetime.combine(booking.check_in, datetime.min.time()))
    if check_in_datetime - timezone.now() < timedelta(hours=24):
        messages.error(request, "You cannot update this booking within 24 hours of check-in.")
        return redirect('my_bookings')

    if request.method == 'POST':
        form = BookingForm(request.POST, instance=booking)
        if form.is_valid():
            form.save()
            messages.success(request, 'Booking updated successfully.')
            return redirect('my_bookings')
    else:
        form = BookingForm(instance=booking)

    return render(request, 'booking_app/update_booking_user.html', {'form': form})


@login_required
def delete_booking_user(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)

    check_in_datetime = timezone.make_aware(datetime.combine(booking.check_in, datetime.min.time()))
    if check_in_datetime - timezone.now() < timedelta(hours=24):
        messages.error(request, "You cannot cancel this booking within 24 hours of check-in.")
        return redirect('my_bookings')

    if request.method == 'POST':
        booking.room.available = True
        booking.room.save()
        booking.delete()
        messages.success(request, "Booking cancelled successfully.")
        return redirect('my_bookings')

    return render(request, 'booking_app/delete_booking_user.html', {'booking': booking})


@login_required
def request_cancellation(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)

    check_in_datetime = timezone.make_aware(datetime.combine(booking.check_in, datetime.min.time()))
    if check_in_datetime - timezone.now() > timedelta(hours=24):
        booking.cancellation_status = 'pending'
        booking.save()
        messages.success(request, "Your cancellation request has been submitted and is pending approval.")
    else:
        messages.error(request, "You can only request cancellation more than 24 hours before check-in.")

    return redirect('my_bookings')


@staff_member_required
def approve_cancellation(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    if request.method == 'POST':
        booking.cancellation_status = 'approved'
        booking.room.available = True
        booking.room.save()
        booking.save()
        messages.success(request, 'Booking cancellation approved.')
        return redirect('admin_dashboard')
    return redirect('admin_dashboard')


@staff_member_required
def decline_cancellation(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id)
    if request.method == 'POST':
        booking.cancellation_status = 'declined'
        booking.save()
        messages.info(request, 'Cancellation request declined.')
        return redirect('admin_dashboard')
    return redirect('admin_dashboard')


@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)

    # ✅ Replace `your_field_name` with actual field from your model
    if booking.check_in - timezone.now().date() < timedelta(days=1):
        messages.error(request, "Cannot cancel the booking less than 24 hours before check-in.")
    else:
        booking.status = 'Pending Cancellation'  # or 'Cancelled' directly
        booking.save()
        messages.success(request, "Cancellation request submitted successfully.")

    return redirect('my_bookings')
# booking/models.py
from datetime import timedelta
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
from hotel_app.models import Hotel, Room 
from django.conf import settings # import hotel/room models

class Booking(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    hotel = models.ForeignKey(Hotel, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    check_in = models.DateField()
    check_out = models.DateField()
    guests = models.PositiveIntegerField()
    booked_at = models.DateTimeField(auto_now_add=True)

    CANCELLATION_STATUS = [
        ('none', 'None'),
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('declined', 'Declined'),
    ]
    cancellation_status = models.CharField(
        max_length=10, choices=CANCELLATION_STATUS, default='none'
    )

    def can_modify(self):
        # Allow update/cancel only if check-in is more than 24 hours away
        return self.check_in > timezone.now().date() + timedelta(days=1)

    def __str__(self):
        return f'{self.user.username} - {self.hotel.name} ({self.check_in} to {self.check_out})'
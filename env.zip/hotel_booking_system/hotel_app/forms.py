from django import forms
from .models import Hotel, Room

class HotelForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = ['name', 'location', 'description', 'price_per_night', 'rating', 'image']


class RoomForm(forms.ModelForm):
    class Meta:
        model = Room
        fields = ['hotel','room_type', 'capacity', 'price', 'available']

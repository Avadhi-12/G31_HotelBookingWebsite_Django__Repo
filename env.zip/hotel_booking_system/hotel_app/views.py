from django.shortcuts import render, redirect, get_object_or_404
from .models import Hotel, Room
from booking_app.models import Booking
from django.contrib.auth.decorators import user_passes_test
from django.db.models import Q
from .forms import HotelForm, RoomForm
from django.contrib.admin.views.decorators import staff_member_required

# -------------------- Public Views --------------------

def home_view(request):
    return render(request, 'home.html')

def hotel_list(request):
    hotels = Hotel.objects.all()

    # Filters
    query = request.GET.get('query')
    location = request.GET.get('location')
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    rating = request.GET.get('rating')

    if query:
        hotels = hotels.filter(Q(name__icontains=query) | Q(location__icontains=query))
    if location:
        hotels = hotels.filter(location__icontains=location)
    if min_price:
        hotels = hotels.filter(price_per_night__gte=min_price)
    if max_price:
        hotels = hotels.filter(price_per_night__lte=max_price)
    if rating:
        hotels = hotels.filter(rating__gte=rating)

    for hotel in hotels:
        hotel.available_rooms = hotel.rooms.filter(available=True).count()

    return render(request, 'hotel_app/hotel_list.html', {'hotels': hotels})

def hotel_detail(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    rooms = hotel.rooms.filter(available=True)
    return render(request, 'hotel_app/hotel_detail.html', {
        'hotel': hotel,
        'rooms': rooms
    })


def admin_required(view_func):
    return user_passes_test(lambda user: user.is_authenticated and user.is_staff)(view_func)


# -------------------- Admin Views --------------------

def is_admin(user):
    return user.is_staff

@staff_member_required
def admin_dashboard(request):
    hotels = Hotel.objects.all()
    bookings = Booking.objects.all()
    return render(request, 'hotel_app/admin_dashboard.html', {
        'hotels': hotels,
        'bookings': bookings
    })

@user_passes_test(is_admin)
def add_hotel(request):
    if request.method == 'POST':
        form = HotelForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
    else:
        form = HotelForm()
    return render(request, 'hotel_app/hotel_form.html', {'form': form, 'title': 'Add Hotel'})

@user_passes_test(is_admin)
def update_hotel(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    if request.method == 'POST':
        form = HotelForm(request.POST, request.FILES, instance=hotel)
        if form.is_valid():
            form.save()
            return redirect('admin_dashboard')
    else:
        form = HotelForm(instance=hotel)
    return render(request, 'hotel_app/hotel_form.html', {'form': form, 'title': 'Update Hotel'})

@user_passes_test(is_admin)
def delete_hotel(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    hotel.delete()
    return redirect('admin_dashboard')

# -------------------- Room Management --------------------

@user_passes_test(is_admin)
def manage_rooms(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    rooms = hotel.rooms.all()
    return render(request, 'hotel_app/manage_rooms.html', {
        'hotel': hotel,
        'rooms': rooms
    })

@user_passes_test(is_admin)
def add_room(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    if request.method == 'POST':
        form = RoomForm(request.POST)
        if form.is_valid():
            room = form.save(commit=False)
            room.hotel = hotel
            room.save()
            return redirect('manage_rooms', hotel_id=hotel.id)
    else:
        form = RoomForm()
    return render(request, 'hotel_app/room_form.html', {'form': form, 'hotel': hotel, 'title': 'Add Room'})

@user_passes_test(is_admin)
def update_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    if request.method == 'POST':
        form = RoomForm(request.POST, instance=room)
        if form.is_valid():
            form.save()
            return redirect('manage_rooms', hotel_id=room.hotel.id)
    else:
        form = RoomForm(instance=room)
    return render(request, 'hotel_app/room_form.html', {'form': form, 'title': 'Update Room'})

@user_passes_test(is_admin)
def delete_room(request, room_id):
    room = get_object_or_404(Room, id=room_id)
    hotel_id = room.hotel.id
    if request.method == 'POST':
        room.delete()
        return redirect('manage_rooms', hotel_id=hotel_id)
    return render(request, 'hotel_app/confirm_delete.html', {'object': room, 'type': 'Room'})




















